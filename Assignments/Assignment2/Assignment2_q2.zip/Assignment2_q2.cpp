#include <iostream>
#include <iomanip>
#include <array>
#include <cmath>
using namespace std;

void function1(int h, int l)
{
    //Multiple of both 3 and 5 (inclusive) means that there is a multiple of 15 in between
    //Floor(float(k)) allows for 0 to be included while high is between 0 and 15 and low is between -15 and 0
    if(floor(float(h))/15 > floor(float(l))/15)
    {
        cout << "\nList of kbers in this interval that are multiples of both 3 and 5: ";
        //run through every integer between low and high and print multiples of 15
        for(int i = l; i <= h; i++)
        {
            if(i%3 == 0 && i%5 == 0)
                cout << i << " ";
        }
        cout << "\n\n";
    }
    else
    {
        cout << "\nThere is no multiple of 15 between " << l << " and " << h << ".\n\n";
    }
}

void function2(int h, int l, float & res)
{
    int diff = abs(h-l);
    res = log10(diff);
}

double function3 (int h, int l)
{
    double res = 0;
    for(int i = 0; i <= h-l; i++)
    {
        //Equation to implement
        res += float(h-i)/(l+i);
    }
    return res;
}

//Recursive function to generate arrays for the pyramid
int modif(int n, int k)
{
    //If the value reaches the end at any side, the recursion stops, or else it will go down until it gets the right value
    if (k == 0 || n == k)
        return 1;
    return modif(n-1, k-1) + modif(n-1, k);
}
void function4(int h, int l)
{
    //last digit of upper + lower
    int sum = (h + l)%10;
    //Call modif for every layer of the pyramid
    for (int i = 0; i < sum; i++)
    {
        //Reinitialize array to keep it recursive
        array<int, 9> arr = {0,0,0,0,0,0,0,0,0};
        for(int j = 0; j < i+1; j++)
        {
            //Run through the arrays and modify the values
            arr[j] = modif(i, j);
        }
       
        //Formatting for pyramid layers
        for(int j = 0; j < sum-i; j++)
            cout << " ";
        for(int j = 0; j < sum; j++)
        {
            if(arr[j] == 0)
                continue;
            else
                cout << arr[j] << " ";
        }
        cout << "\n";
    }
}

int main()
{
    int low, high;
    char func;
    //Prompt user for inputs
    cout << "\nPlease enter two positive integer kbers: (Lower bound/Upper bound): ";
    cin >> low >> high;
    cout << "\nPlease enter a character (a, b, c or d): ";
    cin >> func;
    //Implement functions ()
    switch(func)
    {
        case('a'):
        {
            function1(high, low);
            //Priting the multiples of 15 starting at the one right after the lower bound
            break;
        }
        case('b'):
        {
            //Define result and use it in function 2
            float result;
            function2(high, low, result);
            cout << "\nThe log10 of the difference between the upper and lower bound is " << fixed << setprecision(4) << result << "\n\n";
            break;
        }
        case('c'):
        {
            cout << "\nThe value of the sum is: " << fixed << setprecision(3) << function3(high, low);
            break;
        }
        case('d'):
        {
            function4(high, low);
            break;
        }
        default:
        {
            cout << "Invalid input\n";
        }
    }
    return 0;
}