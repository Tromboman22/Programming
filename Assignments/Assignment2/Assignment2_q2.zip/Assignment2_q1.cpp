#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//Global var to count number of houses
int houses = 0;
//Ask function that asks if the user wants to print a house
int ask(string ans)
{
    cout << "Do you want me to draw a simple house for you? (yes/no) ";
    cin >> ans;
    //Only need to see if user says yes
    if(ans == "yes" || ans == "y")
        return 1;
    else
    {
        if(houses == 0)
        {
            cout << "Have a nice day!";
            return 0;
        }
        cout << "Hope you like your ";
        if(houses > 1)
            cout << houses << " houses!";
        else //Houses == 1
            cout << "house!";
        return 0;
    }
}
//Function to print the houses
int main()
{
    string name, answer;
    int height, width;
    cout << "\nWhat is your name? ";
    cin >> name; 
    cout << "Well " << name << ", welcome to the house drawing program.\n";
    //Ask for details for the house only while user responds 'yes' or 'y' and build the house if neeeded
    while(ask(answer))
    {
        houses += 1;
        cout << "\n Enter the height of the house you want me to draw: ";
        cin >> height;
        //Up to three tries for valid width
        for (int i = 0; i < 3; i++)
        {
            cout << " Please enter a number that is a power of 2 for the width of the house (must be bigger than 4): ";
            cin >> width;
            //Make sure width is at least 4
            if(width > 3)
            {
                //Check if the input is a power of 2
                if(log2(width) == floor(log2(width))) 
                    break; //Both conditions are satisfied, exit for loop
                else       
                    cout << " You enter " << width << " for the width, not a power of 2!\n\n";          
            }
            else        
                cout << " You enter " << width << " for the width. Smaller than 4!\n\n";
            //Either condition is not satisfied
            //Explain why user has failed if this is the last attempt
            if(i == 2)
            {
                if(!cin)
                    cout << " This program only accepts integers. ";
                else if(width%2 ==1)
                    cout << " It seems that you are having trouble entering even numbers! ";
                else if(width < 4)
                    cout << " It seems that you are having trouble entering numbers greater than 3! ";
                else if(log2(width) != floor(log2(width)))
                    cout << " It seems that you are having trouble entering number that are powers of 2! ";
                
                //The specific user error has been explained
                cout << "Program ends now.\n\n";
                return 0;
            }
            
        }
        cout << "\n";
        //Build the roof
        for(int i = 0; i < log2(width); i++)
        {
            //Amount of spaces = half of width - half of hashtags
            for(int j = width/2; j > pow(2,i); j--)
                cout << " ";
            //Amount of hashtags is 2^i, times 2
            for(int j = 0; j < pow(2, i+1); j++)
                cout << "#";
            //Reset for next layer
            cout << "\n";
        }
        //Build the body 
        for(int i = 0; i < height; i++)
        {
            //Print walls with set width for spaces
            cout << "|" << setw(width) << "|\n";
        }
        //Build the floor
        for(int i = 0; i < width; i++)
        {
            cout << "-";
        }
        //Reset for the next iteration of the while loop
        cout << "\n\n";
    }
}