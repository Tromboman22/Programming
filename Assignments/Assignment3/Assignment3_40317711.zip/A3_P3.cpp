#include <iostream>
#include <array>
#include <iomanip>

using namespace std;

void isIdentity(array<array<int, 4>, 4>);
array <int, 16> spiralOrder(array<array<int, 4>, 4>);

int main()
{
    array<array<int, 4>, 4> square; //Initialize 2d array
    cout << "Enter 16 numbers (4 sets of 4): ";
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            cin >> square[i][j]; //Build 2d array
        }
    }

    isIdentity(square); //Check if matrix is identity + print matrix

    cout << "Spiral Order: "; //spiralOrder
    array <int, 16> spiral = spiralOrder(square);
    for(int i = 0; i < 16; i++)
    {
        if(i > 0)   
            cout << ", ";
        cout << spiral[i];
    }
    return 0;
}

void isIdentity(array<array<int, 4>, 4> sqr)
{
    cout << "\nOriginal array:" << endl;
    bool identity = true;
    for(int i = 0; i < 4; i++)
    {
        if (sqr[i][i] != 1)
            identity = false; //Check the diagonals for 1's
        
        for(int j = 0; j < 4; j++)
        {
            if(j != i && sqr[i][j] != 0)
                identity = false; //Check that non diagonals are 0's         
            cout << setw(3) << left << sqr[i][j]; //Print all the elements with a width of 3
        }
        cout << endl;
    }
    cout << endl;
    if(identity == true)
        cout << "isIdentity: The array is an identity matrix.\n\n";
}

array <int, 16> spiralOrder(array<array<int, 4>, 4> spiral)
{
    int i = 0, j = 0; //For indexes to look in the spiral
    int index = 0; //Control the index of the output array
    int incr = 1; //Control the sign of the increment when reading the 2d input array
    array <int, 16> out; //output array initialised
    for(int k = 4; k > 0; k--)
    {
        for(int x = k; x > 0; x--) //x-axis
        {
            out[index] = spiral[i][j];
            ++index;
            if (x != 1)
                j += incr; //Change the index 
            else
                i += incr; //Move to next index for vertical read
        }
        for(int y = k-1; y > 0; y--) //y-axis
        {
            out[index] = spiral[i][j];
            ++index;
            if(y != 1)
                i+= incr;
            else{
                j -= incr;
                incr *= -1; //change the sign of incrementations
            }      
        }
    }
    return out;
}
