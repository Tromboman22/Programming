#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
using namespace std;

//make increment index global instead
string decodeLanguage(string in)
{  
    string out; //Create a string to store the decoded word
    int i = 0, count = 0, cummulative = 0; //global i to increment, count to check for sequences
    char depth = '0'; //To see how many recursions hapenned before previously
    while (i < in.size())
    {
        if (in[i] == ')') //Problem is that on last iteration, program comes here instead of skipping bracket
        {
            reverse(out.begin(), out.end()); //Reverse the contents of the brackets
            for(int j = i; j < in.size(); j++)
            {
                if(in[j] == ')'){
                    out.insert(0, 1, depth + cummulative + 1); //add if last element in respective bracket
                    break;
                }
                else if(in[j] == '('){
                    out.insert(0, 1, depth + 1);
                    break;
                }
            }
            return out;
        }
        else if(in[i] == '(')//Break at parenthesis
        {
            string temp;
            ++i; //Skip over '('

            temp = in.substr(i, in.size()-1);
            cummulative += depth - '0'; //
            temp = decodeLanguage(temp); //Recursion as long as there are open brackets
            depth = (temp[0]); 
            int true_depth = depth - '1'; //Convert to int 
            temp.erase(temp.begin());
            for (char elem:temp)
            {
                out.push_back(elem); //Include the reversed string in the output string
                ++i; //skip elements in unchanged global string
            }
            i += true_depth * 2; //Reaches closing bracket
        }
        else{
        out.push_back(in[i]); //Not a bracket
        }
        ++i; //increment
    }
    return out;
}

int main()
{
    string word;
    cout << "Enter the word to decode: ";
    cin >> word; //Call  decodeLanguage()  
    cout << "Decoded text: " << endl << decodeLanguage(word) << endl;
    return 0;
}