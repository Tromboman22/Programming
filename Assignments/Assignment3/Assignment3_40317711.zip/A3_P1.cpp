#include <iostream>
#include <vector>
#include <array>
using namespace std;


//Initialize globally to have access throughout all functions
vector <int> grades;

//Initialize functions
vector <vector<int>> func1();
int func2();
vector<int> func3();
array<int, 5> func4();


int main(){
    int in;
    char choice;
    int count;
    cout << "Enter student grades (int from 0-100), type -1 to continue: ";
    do 
    {
        cin >> in;
        if (in >= 0 && in <= 100)
        {
            grades.push_back(in);
        }else if (in < -1){
            cout << in << " is an invalid input, int from 0-100 only, -1 to continue\n";
        }
        count = 1;
    }while(in != -1);
    if(grades.size() < 3)
    {
        cout << grades.size() << endl;
        cout << "Number of grades must be greater or equal to 3" << endl;
        cout << "Press 'q' to quit, any other character add more grades: ";
        cin >> choice;
        if (choice != 'q')
            //Call main again to add more elements to grades vector or quit program, will return 0 after so main() won't run a second time
            main();
        return 0;
    }else{
        int num = 0;
        //Formating output to call any function or end program
        cout << "Chose a function:\n1- 3 highest grades, and the corresponding student indices\n2- Median grade\n3- Most frequently occurring grades\n4- Grade distribution\n'q'- End program\nInput: ";
        cin >> choice;
        switch(choice){
            case '1':
            {
                //Call func1 and store the top three grades in the fn1 2d vector
                vector<vector<int>> fn1 = func1();
                int check = 0;
                for(int i = 1; i <= 3; i++)
                {
                    cout << "Top grade #" << i << ": " << fn1[0][i-1] << "%, index number " << fn1[1][i-1] << endl;
                }
                return 0;
            }
            case '2':
            {
                //Call func2 and print out the median
                cout << "The median is " << func2() << "%";
                return 0;
            }
            case '3':
            {
                //Call func3 and store it in a vector
                vector <int> fn3 = func3();
                if(fn3[0] == 1)
                {
                    cout << "No duplicate grades!";
                }else{
                    //When there are two or more people sharing the same grade
                    cout << "There are " << fn3[0] << " students with ";
                    //No ties for most people with a given grade
                    if(fn3.size() == 2)
                        cout << "a grade of " << fn3[1] << "%";
                    else
                    {
                        //Formating for ties: "grade1"" and grade2." (or) "grade1"", grade2"" and grade 3."
                        cout << "grades of ";
                        for(int i = 1; i < fn3.size(); i++)
                        {
                            if (i == 1)
                                cout << fn3[i] << "%";
                            else if(i == fn3.size()-1)
                                cout << " and " << fn3[i] << "%.";
                            else
                                cout << ", " << fn3[i] << "%";
                        }
                    }
                }
                return 0;
            }
            case '4':
            {
                //Initialize an array to store letter grade counts
                array<int, 5> fn4 = func4();
                array<char, 5> letters = {'F', 'D', 'C', 'B', 'A'};
                for(int j = 4; j >= 0; j-=1)
                {
                    //Format "A: count1\n B: count2"
                    cout << letters[j] << ": " << fn4[j] << endl;
                }
                return 0;
            }
            case 'q':
            {
                cout << "Have a nice day!";
                return 0;
            }
            default:
            {
                cout << "Not an option";
                if(num%4 == 0)
                    cout << ", make sure you are pressing the right number, or that you aren't in cap's lock";
            }           
        }        
    }
}


// 1- print 3 highest grades, and the corresponding student indices.
vector <vector<int>> func1(){
    //Temporary vector to hold the 3 highest grades, followed by their indices like so --> temp[grades][indices]
    vector<vector<int>> temp = {{0,0,0},{0,0,0}};
    //Run through all grades
    for (int j = 0; j < grades.size(); j++)
    {
        //Look at the current highest grades
        for (int i = 0; i < 3; i++)
        {
            if(grades[j] > temp[0][i])
            {
                //Insert new top gradein temp[0], and corresponding index in temp[1]
                temp[0].insert(temp[0].begin() + i, grades[j]);
                temp[1].insert(temp[1].begin() + i, j);
                //Remove last grade from temp since it is no longer a top grade, remove last index as well
                temp[0].pop_back();
                temp[1].pop_back();
                //Break after new grade is added to vector
                break;
            }
        }
    }
    return temp;
}


// 2- Median grade
int func2()
{
    //Put the elements in grades in order
    vector <int> order;
    for(int elem : grades)
    {
        for(int i = 0; i < order.size(); i++)
        {
            if(elem > order[i])
            {
                
                //Add element in front of a smaller grade
                order.insert(order.begin() + i, elem);
                //Next iteration of for loop using goto
                
                goto found;
            }          
        }
        //Current element is the new lowest grade
        order.push_back(elem);
        found:
            continue;
        
        
    }
    //Number of elements is odd: median is middle of the pack
    if (order.size()%2 == 1)
    {
        return order[(order.size()-1)/2];
    }else{
        //Number of elements is even: median is the average of the two elements in the middle of the array
        return (order[order.size()/2] + order[(order.size()-1)/2])/2;
    }
}


// 3- Most frequently occurring grades. If multiple grades have the same highest frequency, list all of them
vector <int> func3()
{
    //1st vector to store data and keep track of all the grades, 2nd vector to format the output
    vector<vector<int>> temp = {{},{}}; 
    vector <int> out;
    int max = 1;
    //Going through all the elements in grades
    for(int elem : grades)
    {
        //Comparing with all the elements in the temp array
        for(int i = 0; i < temp[0].size(); i++)
        {
            if(temp[0][i] == elem)
            {
                //Update the number of times a particular grade has appreared
                temp[1][i]+=1;
                if (temp[1][i] > max)
                    max = temp[1][i];
                goto next;
            }

        }
        //Add new grade and 1 at the same index in temp
        temp[0].push_back(elem);
        temp[1].push_back(1);
        //If there was a duplicate, the code skips here to go to the next iteration
        next:
            continue;
    }
    // Build the out array: {max, grade1, grade2...grade n}
    out.push_back(max);
    for(int i = 0; i < temp[0].size(); i++)
    {
        //Check for grades that have max 
        if(temp[1][i] == max)
            out.push_back(temp[0][i]);
    }
    return out;
}


// 4- Grade distribution
array<int, 5> func4()
{
    //Generate an array to keep track of how many people are in each letter grade bracket {f, d, c, b, a}
    array<int, 5> distribution = {0,0,0,0,0};
    for(int elem : grades)
    {
        //check the value of the grade in increasing increments, update the 
        if(elem < 50){
            ++distribution[0]; //Grade: F
            continue;
        }else if(elem < 65){
            ++distribution[1]; //Grade: D
            continue;
        }else if(elem < 80){
            ++distribution[2]; //Grade: C
            continue;
        }else if(elem < 90){
            ++distribution[3]; //Grade: B
            continue;
        }else{
            ++distribution[4]; //Grade: A
            continue;
        }
    }
    return distribution;
}
