#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

int main()
{
    int side; //prompt user for dimensions of square
    cout << "What is the length of your sides? ";
    cin >> side;


    vector<vector<int>> values = {{},{}};
    int tmp, total = 0;
    cout << "Enter " << pow(side,2) << " numbers, " << side << " per row from top to bottom: " << endl;
    
    for(int i = 0; i < side; i++) //build 2d vector
    {
        for(int j = 0; j < side; j++)
        {
            cin >> tmp;

            if(j == i)
            {
                values[0].push_back(tmp); //save the values of the first diagonal
                total += tmp;
            }
            else if(j == side - (i+1)) // doesn't count repeated values (nature of else if)
            {
                values[1].push_back(tmp); // second diagonal
                total += tmp;
            }
        }
    }

    cout << "The sum of two diagonals of the array is " << total << " = ";
    for(int i = 0; i < side; i++)
    {
        cout << values[0][i] << "+"; //first diagonal
    }

    for(int i = 0; i < side - (side%2 + 1); i++) //Exclude repeated value and last value
    {
        cout << values[1][i] << "+"; // second diagonal
    }
    cout << values[1][side - (side%2 + 1)] << ".";
}