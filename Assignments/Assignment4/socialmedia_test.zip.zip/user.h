#pragma once
#include <string>
#include <vector>
#include "post.h"

using namespace std;

class User {
    private:
        int userID;
        string username;
        string bio;
        vector<Post*> posts;
    
    public:
        User();
        User(int id);
        string getUsername();
        void setUsername();
        void setBio();
        void createPost(int id);
        void listPosts();
        int getID();
        bool findPost(int id);
        Post* getPost(int id);
        string getBio();
        void removePosts();
};

/*
userID(int, a unique identifier for each user.)
username(string)
bio (string, a brief description of the user.)
posts (vector of Post objects containing a list of the user’s posts.)

It has the following Member Functions:
1) Get and set functions for username;
2) createPost - Creates a new Post and adds it to the posts list.
3) listPosts - Prints all posts by the user, displaying post IDs, content, likes.
*/