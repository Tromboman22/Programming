#include <string>
#include <iostream>
#include <limits>
#include <vector>
#include "post.h"
#include "user.h"
#include "socialmediaplatform.h"

using namespace std;

User::User()
{
    userID = 0;
}

User::User(int id)
{
    userID = id; //keep track of id's in the main func
    setUsername();
    setBio();
}

string User::getUsername()
{
    return username;
}

void User::setUsername()
{
    cout << "Enter username: ";
    cin >> username; // username for new user
}

void User::setBio()
{
    cout << "Enter bio: ";
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); //clear cin from setUsername(), while using both getline() and cin in the same code
    getline(cin, bio);
}

void User::createPost(int id)
{
    string msg;
    cout << "Enter post content: ";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    getline(cin, msg);
    posts.push_back(new Post(id, msg));
}

void User::listPosts()
{
    cout << "Posts: " << endl;

    for(Post* elem: posts)
    {
        elem->viewPost();
    }
}

int User::getID()
{
    return userID;
}

bool User::findPost(int id)
{
    for(Post* post : posts)
    {
        if(post->getID() == id)
        {
            return true;
        }
    }
    return false;
}

Post* User::getPost(int id)
{
    for(Post* post : posts)
    {
        if(post->getID() == id)
        {
            return post;
        }
    }
    
    Post* empty = new Post();
    return empty; //empty post to signal fail
}

string User::getBio()
{
    return bio;
}

void User::removePosts()
{
    for(Post* post : posts)
    {
        post->deleteComments();
        delete post;
    }
}
