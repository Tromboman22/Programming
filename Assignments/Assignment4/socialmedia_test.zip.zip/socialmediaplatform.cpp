#include <string>
#include <vector>
#include <iostream>
#include <limits>
#include "user.h"
#include "post.h"
#include "socialmediaplatform.h"


using namespace std;


SocialMediaPlatform::SocialMediaPlatform()
{
    users = {};
    IDnum = 1;
    IDpost = 1;
}

void SocialMediaPlatform::registerUser()
{
    User *person = new User(IDnum++); //increment ID for next user
    users.push_back(person);
    cout << "User ID: " << person->getID() << endl; //Shows user ID of new User

    cout << "\nEnter to continue" << endl;
    cin.get();
}

void SocialMediaPlatform::removeUser()
{
    int id;
    cout << "User ID to remove: ";
    cin >> id;
    for(int i = 0; i < users.size(); i++)
    {
        if(id == users[i]->getID()) //getID returns user ID, an integer
        {
            cout << "Deleted the profile of: " 
            << users[i]->getUsername() << endl;
            delete users[i];
            users.erase(users.begin() + i);
            break;
        }
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); //program bugs without ignoring cin here
    cout << "\nEnter to continue" << endl;
    cin.get();
}

User* SocialMediaPlatform::findUserByName(string name)
{
    for(int i = 0; i < users.size(); i++)
    {
        if(users[i]->getUsername() == name)
        {
            return users[i];
            break;
        }
    }
    cout << "No such user" << endl;
    return new User(); //create an empty user to signal fail
}

void SocialMediaPlatform::createPostForUser()
{
    cout << "Enter username to create post for: ";
    string in;
    cin >> in;
    User* tmp = findUserByName(in);

    if(tmp->getID() == 0) //Empty user will have userID of 0
    {
        delete tmp; //free empty user memory space
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); //program bugs after skip without ignoring cin here
        goto skip1;
    }

    tmp->createPost(IDpost++); //increment for next
    cout << "Post ID: " << tmp->getPost(IDpost-1)->getID() << endl;

    skip1: //In case of invalid username
    
    cout << "\nEnter to continue" << endl;
    cin.get();

    
}

void SocialMediaPlatform::likePost()
{
    cout << "Enter username who likes the post: ";
    string in;
    cin >> in; 
    int check = 0;
    User* tmp = findUserByName(in); // see if user exists

    if(tmp->getID() == 0)
    {
        delete tmp; //delete empty user
        goto skip2;
    }

    cout << "Enter post ID to like: ";
    int id;
    cin >> id;
    
    for(int i = 0; i < users.size(); i++)
    {
        if(users[i]->findPost(id))
        {   //add a like
            cout << users[i]->getUsername() << "'s post ++likes" << endl;
            users[i]->getPost(id)->addLike();
            check = 1;
            break;
        }
    }
    if(check == 0)
        cout << "Invalid Post ID." << endl;

    //Invalid username    
    skip2: 
        cout; //Validates the skip
}

void SocialMediaPlatform::commentOnPost()
{
    cout << "Enter username who comments: ";
    string in;
    cin >> in;
    int check = 0;
    User* tmp = findUserByName(in); // see if user exists

    if(tmp->getID() == 0)
    {
        delete tmp; //delete empty user
        goto skip3;
    }

    cout << "Enter post ID to comment on: ";
    int id;
    cin >> id;
    for(int i = 0; i < users.size(); i++)
    {
        if(users[i]->findPost(id))
        {   //add a comment with name
            users[i]->getPost(id)->addComment(in);
            check = 1;
            break;
        }
    }

    if(check == 0)
        cout << "Invalid Post ID." << endl;

    //Invalid user
    skip3: 
        cout; //Validates the skip
}

void SocialMediaPlatform::viewUserProfile()
{
    cout << "Enter username to view profile: ";
    string in;
    cin >> in;
    cout << "\nProfile of " << in << ":\nBio: ";
    User* usr = findUserByName(in); //pointer to user in question

    if(usr->getID() == 0)
    {
        delete usr; //delete empty user
        goto skip4;
    }

    cout << usr->getBio() << endl;
    usr->listPosts();
    
    skip4: //invalid username

    cin.ignore(numeric_limits<streamsize>::max(), '\n'); //program bugs without ignoring cin here
    cout << "\nEnter to continue" << endl;
    cin.get();

}

void SocialMediaPlatform::removeAll()
{
    for(User* usr : users)
    {
        usr->removePosts();
        delete usr; //free all the memory
    }
}

void SocialMediaPlatform::listUsers()
{
    cout << "Users: " << endl;
    for(User* usr : users)
    {
        cout << " -" << usr->getUsername() << ", ID: " << usr->getID() << endl;
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); //program bugs without ignoring cin here
    cout << "\nEnter to continue" << endl;
    cin.get();
}