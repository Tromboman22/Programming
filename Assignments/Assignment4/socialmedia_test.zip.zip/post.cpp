#include <string>
#include <iostream>
#include <vector>
#include <iomanip>
#include <limits>
#include "post.h"

using namespace std;


Post::Post()
{
    postID = 0;
}

Post::Post(int id, string msg)
{
    postID = id; //Initialize all
    content = msg;
    likes = 0;
    comments = {};
}

void Post::addLike()
{
    ++likes;
}

void Post::addComment(string fr)
{
    string str;
    cout << "Enter comment: ";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    getline(cin, str); 
    string* cmnt = new string(fr + ": " + str);
    comments.push_back(cmnt); //string pointers in comments
}
void Post::viewPost()
{
    cout << "- Post ID: " << postID << endl
    << "  Content: " << content << endl
    << "  Likes: " << likes << endl
    << "  Comments:\n";

    for(int i = 0; i < comments.size(); i++)
    {
        cout << right << setw(comments[i]->size() + 4) << *comments[i] << endl; 
    }
}

int Post::getID()
{
    return postID;
}

void Post::deleteComments()
{
    for(string* elem : comments)
    {
        delete elem;
    }
}
