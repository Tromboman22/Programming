#pragma once
#include <string>
#include <vector>

using namespace std;

class Post {
    private:
        int postID, likes;
        string content;
        vector<string*> comments;
    
    public:
        Post();
        Post(int id, string msg);
        void addLike();
        void addComment(string fr);
        void viewPost();
        int getID();
        void deleteComments();
};


/*
Post class represents individual posts created by users
Each post includes content
a count of likes
comments from other users

It has the following attributes: 
postID (int, A unique identifier for each post)
content (string, The content of the post)
likes (int, Number of likes the post has received)
comments (vector of string, A list of comments on the post).

It has the following Member Functions:
1) addLike - Increments the likes count.
2) addComment - Adds a comment to comments.
3) viewPost - Displays the content, number of likes, and all comments.
*/