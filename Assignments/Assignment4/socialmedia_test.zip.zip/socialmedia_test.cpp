#include "user.h"
#include "post.h"
#include "socialmediaplatform.h"
#include <iostream>
#include <limits>

using namespace std;

int main()
{
    SocialMediaPlatform platform =  SocialMediaPlatform();

    cout << "\nWelcome to the Social Media Platform Simulation!\n";

    while(true)
    {
        //initial message
        cout << "\n1. Register new user" << endl
            << "2. Create a post" << endl
            << "3. Like a post" << endl
            << "4. Comment on a post" << endl
            << "5. View user profile" << endl 
            << "6. List users" << endl 
            << "7. Remove user" << endl
            << "8. Exit\n" << endl
            << "Enter your choice: ";
        int in;
        cin >> in;

        switch (in)
        {
        case 1:
            platform.registerUser();
            break;
        case 2:
            platform.createPostForUser();
            break;
        case 3:
            platform.likePost();
            break;
        case 4:
            platform.commentOnPost();
            break;
        case 5:
            platform.viewUserProfile();
            break;
        case 6: 
            platform.listUsers();
            break;
        case 7:
            platform.removeUser();
            break;
        case 8: 
        {
            platform.removeAll();
            cout << "Goodbye!";
            return 0; //Free memory and exit program
        }

        default:
            cout << "Invalid input." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); //clear cin if fails
            break;
        }

    }
}