#pragma once
#include <string>
#include <vector>
#include "user.h"
#include "post.h"

using namespace std;

class SocialMediaPlatform {
    private:
        vector<User*> users;
        int IDnum;
        int IDpost;
    
    public:
        SocialMediaPlatform();
        void registerUser();
        void removeUser();
        User* findUserByName(string name);
        void createPostForUser();
        void likePost();
        void commentOnPost();
        void viewUserProfile();
        void removeAll();
        void listUsers();
};



/*
SocialMediaPlatform class manages the entire platform, including:
user registration, post creation, and user interactions. 
It has the following attributes: 
users (vector of User objects, A list of all registered users).

It has the following Member Functions:

1) registerUser - Adds a new User to the platform by taking username and bio as input
Whenever register a new user, a userID should be set as well
The userID is not input by the user, instead it is assigned by the program
userID should be unique without repetition.

2) removeUser - Removes a user by userID.
3) findUserByUsername - Returns a pointer to a User given the username.
4) createPostForUser - Allows a specific user to create a post.
5) likePost - Increments likes for a specific post by a specific user.
6) commentOnPost - Allows a user to comment on another user's post.
7) viewUserProfile - Prints a user’s profile with posts, likes, and comments.
*/