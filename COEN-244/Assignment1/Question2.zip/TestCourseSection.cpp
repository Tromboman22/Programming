#include "CourseSection.h"
#include <iostream>

int main()
{
    int counter = 1;
    CourseSection section = CourseSection(counter);
    section.printinfo();
    return 0;
}
