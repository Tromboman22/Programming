#include "Professor.h"
#include <iostream>

int main()
{
    int counter = 1;
    Professor section = Professor(counter);
    section.printinfo();
    return 0;
}
